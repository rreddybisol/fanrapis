package FANRADVPClient;

// -----( IS Java Code Template v1.2

import com.wm.data.*;
import com.wm.util.Values;
import com.wm.app.b2b.server.Service;
import com.wm.app.b2b.server.ServiceException;
// --- <<IS-START-IMPORTS>> ---
import java.text.SimpleDateFormat;
import java.util.Date;
// --- <<IS-END-IMPORTS>> ---

public final class services

{
	// ---( internal utility methods )---

	final static services _instance = new services();

	static services _newInstance() { return new services(); }

	static services _cast(Object o) { return (services)o; }

	// ---( server methods )---




	public static final void formatDates (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(formatDates)>> ---
		// @sigtype java 3.5
		IDataCursor pipelineCursor = pipeline.getCursor();
		
		try {
		    // Retrieve input 'inspDate' (assume it's passed as a String in "yyyy-MM-dd" format)
		    String inspDateStr = null;
		    if (pipelineCursor.first("inspDate")) {
		        inspDateStr = (String) pipelineCursor.getValue();
		    }
		
		    if (inspDateStr == null || inspDateStr.isEmpty()) {
		        throw new ServiceException("Input 'inspDate' is required.");
		    }
		
		    // Parse the input date
		    SimpleDateFormat inputDateFormat = new SimpleDateFormat("yyyy-MM-dd");
		    Date startDate = inputDateFormat.parse(inspDateStr);
		
		    // Initialize date and format
		    Date endDate = new Date();
		    SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss");
		
		    // Calculate end date (90 days later)
		    endDate.setTime(startDate.getTime() + 90L * 1000 * 60 * 60 * 24);
		
		    // Format dates
		    String formattedStartDate = sdf.format(startDate);
		    String formattedEndDate = sdf.format(endDate);
		
		    // Put output into pipeline
		    IDataUtil.put(pipelineCursor, "formattedStartDate", formattedStartDate);
		    IDataUtil.put(pipelineCursor, "formattedEndDate", formattedEndDate);
		
		} catch (Exception e) {
		    throw new ServiceException("Error processing dates: " + e.getMessage());
		} finally {
		    pipelineCursor.destroy();
		}
		// --- <<IS-END>> ---

                
	}
}

