package FANRCustomerPulse.services;

// -----( IS Java Code Template v1.2

import com.wm.data.*;
import com.wm.util.Values;
import com.wm.app.b2b.server.Service;
import com.wm.app.b2b.server.ServiceException;
// --- <<IS-START-IMPORTS>> ---
import java.util.regex.*;
// --- <<IS-END-IMPORTS>> ---

public final class java

{
	// ---( internal utility methods )---

	final static java _instance = new java();

	static java _newInstance() { return new java(); }

	static java _cast(Object o) { return (java)o; }

	// ---( server methods )---




	public static final void formatMobileNumber (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(formatMobileNumber)>> ---
		// @sigtype java 3.5
		// [i] field:0:required mobileFromRequest
		// [o] field:0:required formattedMobileNumber
		IDataCursor pipelineCursor = pipeline.getCursor();
		String mobileFromRequest = null;
		String countryCode = "+971"; // Default country code
		String mobNumber = null;
		
		// Retrieve input value
		if (pipelineCursor.first("mobileFromRequest")) {
		    mobileFromRequest = (String) pipelineCursor.getValue();
		}
		
		// Validate input
		if (mobileFromRequest == null || mobileFromRequest.isEmpty()) {
		    throw new ServiceException("Input 'mobileFromRequest' is required and cannot be null or empty.");
		}
		
		try {
		    // Remove non-digit characters
		    String phNo = mobileFromRequest.replaceAll("\\D+", "");
		
		    // Extract the last 9 digits
		    if (phNo.length() >= 9) {
		        String lastNineDigits = phNo.substring(phNo.length() - 9);
		        mobNumber = countryCode + lastNineDigits;
		    }
		
		    // Set the formatted number in the pipeline
		    IDataUtil.put(pipelineCursor, "formattedMobileNumber", mobNumber);
		
		} catch (Exception e) {
		    throw new ServiceException("Error processing the mobile number: " + e.getMessage());
		} finally {
		    pipelineCursor.destroy();
		}
			
		// --- <<IS-END>> ---

                
	}
}

